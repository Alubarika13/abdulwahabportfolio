// ---------- Category taxonomy ----------
const CATS = {
  saas:        {label:"SaaS & Tech", cls:"cat-saas"},
  agency:      {label:"Agency & Creative", cls:"cat-agency"},
  health:      {label:"Healthcare & Wellness", cls:"cat-health"},
  hospitality: {label:"Hospitality & Travel", cls:"cat-hospitality"},
  food:        {label:"Food & Beverage", cls:"cat-food"},
  home:        {label:"Home & Local Services", cls:"cat-home"},
  legal:       {label:"Legal & Professional", cls:"cat-legal"},
  nonprofit:   {label:"Nonprofit & Civic", cls:"cat-nonprofit"},
  edu:         {label:"Education & Coaching", cls:"cat-edu"},
};

// ---------- Full project list (37) ----------
// img: filename in assets/img/, or null (falls back to a category-tinted placeholder)
const PROJECTS = [
  {id:"designjoy", name:"DesignJoy", url:"https://www.designjoy.co/", cats:["agency"], desc:"Productized design-subscription brand: clean, conversion-first landing structure.", img:"designjoy.jpg", featured:true},
  {id:"coraggiogroup", name:"Coraggio Group", url:"https://coraggiogroup.com/", cats:["legal"], desc:"Strategy & organizational-effectiveness consultancy: credibility-first structure.", img:"coraggiogroup.jpg", featured:true},
  {id:"quickenrich", name:"QuickEnrich", url:"https://quickenrich.io/", cats:["saas"], desc:"B2B data enrichment platform: API-docs and login-driven SaaS marketing site.", img:"quickenrich.jpg"},
  {id:"buzzinteractive", name:"Buzz Interactive", url:"https://www.buzzinteractive.co/", cats:["agency"], desc:"Full-service product agency site with live chat lead capture.", img:"buzzinteractive.jpg"},
  {id:"elevantee", name:"Elevantee", url:"https://elevantee.webflow.io/", cats:["agency"], desc:"Brand elevation studio: editorial, portrait-led landing page.", img:"elevantee.jpg"},
  {id:"shawarmaqueen", name:"Shawarma Queen", url:"https://shawarmaqueen.webflow.io/", cats:["food"], desc:"Restaurant brand site with online ordering and a CMS-driven menu.", img:"shawarmaqueen.jpg"},
  {id:"thinkhealth", name:"Think Health & Wellness", url:"https://www.thinkhealthandwellness.com/", cats:["health"], desc:"Wellness content hub with newsletter capture and telehealth consult CTA.", img:"thinkhealth.jpg"},
  {id:"bobolobo", name:"Bobolobo", url:"https://bobolobo.webflow.io/", cats:["edu"], desc:"Early-childhood program site: playful brand system for parents.", img:"bobolobo.jpg"},
  {id:"mountainscapers", name:"Mountainscapers", url:"https://www.mountainscapers.com/", cats:["home"], desc:"Landscape architecture & construction: multi-location service site.", img:"mountainscapers.jpg", featured:true},
  {id:"xenith", name:"Xenith", url:"https://xenith-design.webflow.io/", cats:["agency"], desc:"Bold brand-design studio site with an editorial image collage hero.", img:"xenith.jpg"},
  {id:"fedorova", name:"Fedorova Architects", url:"https://fedorova.ru/en/", cats:["agency"], desc:"Architecture & interiors studio: image-led, gallery-first structure.", img:"fedorova.jpg", featured:true},
  {id:"cabuya", name:"Cabuya Lodge", url:"https://cabuya-lodge.webflow.io/", cats:["hospitality"], desc:"Costa Rica jungle retreat with a WeTravel booking API integration.", img:"cabuya.jpg", featured:true},
  {id:"blacktomato", name:"Black Tomato", url:"https://www.blacktomato.com/", cats:["hospitality"], desc:"Luxury travel brand reference: rich imagery, refined typography.", img:"blacktomato.jpg"},
  {id:"verityhealth", name:"Verity", url:"https://www.verityhealth.io/", cats:["health","saas"], desc:"Behavioral-health incentive platform for patients and staff.", img:"verityhealth.jpg", featured:true},
  {id:"octopus", name:"Octopus Outbound", url:"https://octopusoutbound.webflow.io/", cats:["agency","saas"], desc:"Outbound sales agency: bold dark-mode brand with an AI chat widget.", img:"octopus.jpg"},
  {id:"igloo", name:"Igloo Developments", url:"https://igloodevelopments.com/", cats:["home"], desc:"Property developer site: portfolio of residential builds.", img:"igloo.jpg"},
  {id:"cmodel", name:"CModel", url:"https://cmodel.io/", cats:["saas"], desc:"Decision-intelligence platform for economic development orgs.", img:"cmodel.jpg", featured:true},
  {id:"elitesedation", name:"Elite Sedation", url:"https://elitesedation.com/", cats:["health"], desc:"Pediatric dental sedation service: trust-first, patient-focused site.", img:"elitesedation.jpg"},
  {id:"kubeshark", name:"Kubeshark", url:"https://kubeshark.com/", cats:["saas"], desc:"Kubernetes network-observability dev tool: technical, docs-first site.", img:"kubeshark.jpg"},
  {id:"eatsantotaco", name:"Santo Taco", url:"https://www.eatsantotaco.com/", cats:["food"], desc:"Taco brand site with an email-club popup and full ordering/catering nav.", img:"eatsantotaco.jpg"},
  {id:"meaningfulactivities", name:"Meaningful Activities", url:"https://meaningfulactivities.com.au/", cats:["health"], desc:"Neurodiversity-affirming occupational therapy service, Australia.", img:"meaningfulactivities.jpg"},
  {id:"massanuttencc", name:"Massanutten Country Corner", url:"https://massanuttencc.com/", cats:["hospitality"], desc:"Shenandoah Valley farm market & gift shop: visitor-attraction site.", img:"massanuttencc.jpg"},
  {id:"xptavern", name:"XP Tavern", url:"https://www.xptavern.com/", cats:["food"], desc:"London gaming social lounge/bar: booking-first, video-hero site.", img:"xptavern.jpg"},
  {id:"teamdemocracy", name:"Team Democracy", url:"https://www.teamdemocracy.org/", cats:["nonprofit"], desc:"Civic advocacy organization: donation and campaign-driven site.", img:"teamdemocracy.jpg"},
  {id:"carenova", name:"CareNova", url:"https://carenova-oly.webflow.io/", cats:["health"], desc:"Medical treatment center site built for appointment booking.", img:"carenova.jpg"},
  {id:"apexcare", name:"ApexCare", url:"https://apexcare.webflow.io/", cats:["health"], desc:"Dental clinic site with a booking-first hero and trust badges.", img:"apexcare.jpg"},
  {id:"husslin", name:"Husslin", url:"https://husslin.webflow.io/", cats:["saas","home"], desc:"App connecting users with local artisans and professionals on demand.", img:"husslin.jpg"},
  {id:"trymonee", name:"Monee", url:"https://trymonee.webflow.io/", cats:["saas"], desc:"Cross-border money-transfer app marketing site with payment-brand trust bar.", img:"trymonee.jpg"},
  {id:"tobiaslaw", name:"Tobias Law Firm", url:"https://tobiaslawfirm.webflow.io/", cats:["legal"], desc:"Law firm site built for credibility and consultation requests.", img:"tobiaslaw.jpg"},
  {id:"aimastering", name:"AI Mastering Academy", url:"https://aimasteringacademy.com/", cats:["edu"], desc:"AI business-training academy with a gated mini-course lead funnel.", img:"aimastering.jpg"},
  {id:"zenhr", name:"ZenHR", url:"https://www.zenhr.com/en/hr-software-saudi-arabia", cats:["saas"], desc:"Enterprise HR & payroll software site built for the Saudi market.", img:"zenhr.jpg"},
  {id:"shamrock", name:"Shamrock Catering Co", url:"https://shamrock.com.hk/", cats:["food"], desc:"Hong Kong's premier event caterer since 1994: multi-service nav.", img:"shamrock.jpg"},
  {id:"axcreative", name:"AX Creative", url:"https://axcreative.co/", cats:["agency"], desc:"Melbourne creative & marketing agency with a bold editorial hero.", img:"axcreative.jpg"},
  {id:"truvity", name:"Truvity", url:"https://www.truvity.com/", cats:["saas"], desc:"eIDAS 2.0 / EUDI wallet infrastructure platform for enterprise identity.", img:"truvity.jpg", featured:true},
  {id:"physitrack", name:"Physitrack", url:"https://www.physitrack.com/en-gb", cats:["health","saas"], desc:"Telehealth & remote physiotherapy exercise-prescription platform.", img:"physitrack.jpg"},
  {id:"appora", name:"Appora", url:"https://appora.au/", cats:["saas"], desc:"AI business-automation platform: apps, social scheduling, and chat assistant.", img:"appora.jpg"},
];

// gradient fallback per category, for projects without a real thumbnail yet
const CAT_GRADIENT = {
  saas:["#3457D5","#1B2A66"], agency:["#E8A33D","#5B4B26"], health:["#2E7D6B","#123A32"],
  hospitality:["#C1553A","#5E2A1D"], food:["#9E2B25","#3E110E"], home:["#5B6472","#20242B"],
  legal:["#1B2A66","#0E1116"], nonprofit:["#5B4B8A","#241D3A"], edu:["#3D7A99","#17303C"],
};

function catPillsHTML(cats){
  return `<div class="cat-pills">${cats.map(c => `<span class="cat-pill ${CATS[c].cls}"><span class="dot"></span>${CATS[c].label}</span>`).join('')}</div>`;
}

function cardHTML(p, imgBase, delayIndex){
  const displayUrl = p.url.replace(/^https?:\/\//,'').replace(/\/$/,'');
  const grad = CAT_GRADIENT[p.cats[0]];
  const previewInner = p.img
    ? `<img src="${imgBase}${p.img}" alt="${p.name} homepage screenshot" loading="lazy">`
    : `<span class="wordmark">${p.name}</span>`;
  const previewClass = p.img ? "browser-preview" : "browser-preview is-placeholder";
  const previewStyle = p.img ? "" : ` style="background:linear-gradient(135deg, ${grad[0]}, ${grad[1]});"`;
  return `
    <div class="browser-card reveal" data-cats="${p.cats.join(' ')}" style="--d:${delayIndex % 3}">
      <div class="browser-chrome">
        <div class="dots"><span></span><span></span><span></span></div>
        <div class="url">${displayUrl}</div>
      </div>
      <a href="${p.url}" target="_blank" rel="noopener">
        <div class="${previewClass}"${previewStyle}>${previewInner}</div>
      </a>
      <div class="browser-body">
        ${catPillsHTML(p.cats)}
        <h3>${p.name}</h3>
        <p>${p.desc}</p>
        <a class="visit" href="${p.url}" target="_blank" rel="noopener">Visit live site
          <svg width="11" height="11" viewBox="0 0 12 12" fill="none"><path d="M3 9L9 3M9 3H4M9 3V8" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </a>
      </div>
    </div>`;
}

// ---------- Render: curated grid on the main page ----------
function renderFeatured(containerId, imgBase){
  const el = document.getElementById(containerId);
  if(!el) return;
  const featured = PROJECTS.filter(p => p.featured);
  el.innerHTML = featured.map((p,i) => cardHTML(p, imgBase, i)).join('');
  observeReveal();
}

// ---------- Render: full grid + filters on work.html ----------
function renderFullGrid(gridId, filterBarId, imgBase){
  const grid = document.getElementById(gridId);
  const bar = document.getElementById(filterBarId);
  if(!grid || !bar) return;
  grid.innerHTML = PROJECTS.map((p,i) => cardHTML(p, imgBase, i)).join('');

  const chips = [{key:"all", label:"All Work"}, ...Object.entries(CATS).map(([key,v]) => ({key, label:v.label, cls:v.cls}))];
  bar.innerHTML = chips.map(c => `<button class="filter-chip ${c.key==='all' ? 'active' : ''}" data-filter="${c.key}"><span class="dot ${c.cls||''}"></span>${c.label}</button>`).join('');

  const cards = Array.from(grid.querySelectorAll('.browser-card'));
  const emptyNote = document.getElementById('emptyNote');

  bar.addEventListener('click', (e) => {
    const btn = e.target.closest('.filter-chip');
    if(!btn) return;
    bar.querySelectorAll('.filter-chip').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const filter = btn.dataset.filter;
    let visibleCount = 0;
    cards.forEach(card => {
      const cats = card.dataset.cats.split(' ');
      const show = filter === 'all' || cats.includes(filter);
      card.classList.toggle('hide', !show);
      if(show) visibleCount++;
    });
    if(emptyNote) emptyNote.style.display = visibleCount === 0 ? 'block' : 'none';
  });

  observeReveal();
}

// ---------- Testimonials (marquee, all shown, no separate page) ----------
const TESTIMONIALS = [
  {quote:"Awesome profesional, I recommend 100%!! It's the best webflow developer, fast delivering his job, i gonna re hire him for my future projects.", who:"Sergi Ramirez", role:"Webflow Website: B2B Dental Agency | Conversion-Focused", stars:5},
  {quote:"Working with Abdulwahab on our Webflow project was an outstanding experience from start to finish. We needed someone to replicate an existing website design inside Webflow with pixel-perfect accuracy, and he delivered exactly that and more.", who:"Zabeth Aremu", role:"Webflow Designer Needed to Replicate Existing Website", stars:5},
  {quote:"Excellent Webflow Developer! He recreated our HTML site pixel perfect in Webflow. The build closely matched the original design, followed the Finsweet Client-First structure, and was fully responsive with smooth animations.", who:"Bright Mind", role:"Webflow Developer to Convert HTML to Webflow Using Finsweet Client-First", stars:5},
  {quote:"Working with Abdulwahab was an absolute pleasure from start to finish. He delivered a pixel-perfect conversion of our Figma designs into a fully responsive Webflow website, complete with CMS Collections, dynamic blog templates, and custom landing pages all exactly as briefed. What stood out most was their attention to detail and proactive communication. They anticipated issues before they arose and always came with solutions. The CMS setup was clean and intuitive, making it easy for our team to manage content without any technical background.", who:"Emma Obetta", role:"Webflow Designer & Developer Needed (CMS, Blog & Landing Pages)", stars:5},
  {quote:"Abdulwahab is a exceptional Webflow expert and developer. I hired him to build a high-converting Webflow landing page with conversion-focused design, mobile-first layout, and Calendly booking integration, all within 3-5 days, and he delivered flawlessly. His Webflow UI/UX design skills, attention to visual hierarchy, and understanding of Core Web Vitals and performance optimization resulted in a fast, SEO-optimized, and fully responsive Webflow website. The user experience was clean, modern, and built to convert. If you need a reliable Webflow developer for a lead generation page, SaaS website, or any business website, Abdulwahab is your guy. Will absolutely hire again.", who:"Ellis Organisation", role:"Webflow Designer Needed for Lead Generation Landing Page", stars:5},
  {quote:"Awesome designer!", who:"Sergi Ramirez", role:"Changes at the landing page · Returning client", stars:5},
  {quote:"Abdulwahab did an excellent job on our Webflow project. He quickly replicated the required sections from Figma, paid attention to detail, and ensured everything was responsive and aligned with the design. The work was completed on time and exactly as requested. I would definitely recommend him and look forward to working with him again.", who:"Ken Dips", role:"Webflow Developer Needed for Quick Updates on my Lead Generation Landing Page", stars:5},
];

function starsHTML(n){
  return `<div class="t-stars">${'★'.repeat(n)}${'☆'.repeat(5-n)}</div>`;
}

function testimonialCardHTML(t){
  const initials = t.who.split(' ').map(w=>w[0]).slice(0,2).join('').toUpperCase();
  return `
    <div class="t-card">
      <span class="quote-mark">"</span>
      ${starsHTML(t.stars || 5)}
      <p>${t.quote}</p>
      <div class="t-who">
        <div class="t-avatar">${initials}</div>
        <div><b>${t.who}</b><span>${t.role}</span></div>
      </div>
    </div>`;
}

// Renders a slow, seamless horizontal marquee. The list is duplicated once so the
// loop has no visible seam. Pauses on hover/focus so a reader can finish a card.
function renderMarquee(trackId){
  const track = document.getElementById(trackId);
  if(!track) return;
  const cardsHTML = TESTIMONIALS.map(t => testimonialCardHTML(t)).join('');
  track.innerHTML = cardsHTML + cardsHTML; // duplicate for seamless loop
}


// ---------- FAQs (placeholder copy, user will send real content) ----------
const FAQS = [
  {q:"What platforms do you build on?", a:"Webflow is my main platform, but depending on the project I also work in WordPress, Shopify, WIX, and a handful of others listed in the Skills section above."},
  {q:"How long does a typical project take?", a:"A landing page usually ships in 3 to 7 days. A full multi-page CMS-driven site typically runs 2 to 4 weeks, depending on scope and how quickly content and feedback come back."},
  {q:"Do you only build the design, or also handle CMS and integrations?", a:"Both. I handle the full build, from Figma-to-Webflow conversion through CMS architecture, third-party integrations, and Core Web Vitals/SEO work."},
  {q:"Can you redesign an existing site without losing our SEO rankings?", a:"Yes. Migrations are planned around preserving your existing URL structure, redirects, and content, so rankings carry over rather than resetting."},
  {q:"How do we get started?", a:"Send a message through Upwork, WhatsApp, or email with a short brief. I'll follow up with next steps, usually within a day."},
];

function renderFAQs(containerId){
  const el = document.getElementById(containerId);
  if(!el) return;
  el.innerHTML = FAQS.map((f,i) => `
    <div class="faq-item" data-i="${i}">
      <button class="faq-question" type="button" aria-expanded="false">
        <span>${f.q}</span>
        <span class="plus">+</span>
      </button>
      <div class="faq-answer"><p>${f.a}</p></div>
    </div>`).join('');

  el.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', () => {
      const item = btn.closest('.faq-item');
      const answer = item.querySelector('.faq-answer');
      const isOpen = item.classList.contains('open');
      // close any other open item (accordion behavior)
      el.querySelectorAll('.faq-item.open').forEach(openItem => {
        if(openItem !== item){
          openItem.classList.remove('open');
          openItem.querySelector('.faq-question').setAttribute('aria-expanded','false');
          openItem.querySelector('.faq-answer').style.maxHeight = null;
        }
      });
      item.classList.toggle('open', !isOpen);
      btn.setAttribute('aria-expanded', String(!isOpen));
      answer.style.maxHeight = isOpen ? null : answer.scrollHeight + 'px';
    });
  });
}

function observeReveal(){
  const revealEls = document.querySelectorAll('.reveal:not(.in)');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if(entry.isIntersecting){
        entry.target.classList.add('in');
        io.unobserve(entry.target);
      }
    });
  }, {threshold:0.1});
  revealEls.forEach(el => io.observe(el));
}
document.addEventListener('DOMContentLoaded', observeReveal);
window.addEventListener('load', () => {
  document.querySelectorAll('.hero .reveal').forEach(el => el.classList.add('in'));
});

// ---------- Count-up stats ----------
const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function countUp(el){
  const target = parseInt(el.dataset.count, 10);
  const suffix = el.dataset.suffix || '';
  if(prefersReduced){ el.textContent = target + suffix; return; }
  let start = null;
  const duration = 1200;
  function step(ts){
    if(!start) start = ts;
    const progress = Math.min((ts - start) / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.round(eased * target) + suffix;
    if(progress < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}
document.addEventListener('DOMContentLoaded', () => {
  const statEls = document.querySelectorAll('.stat b[data-count]');
  const statIo = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if(entry.isIntersecting){ countUp(entry.target); statIo.unobserve(entry.target); }
    });
  }, {threshold:0.4});
  statEls.forEach(el => statIo.observe(el));

  // Mobile nav toggle
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');
  if(navToggle && navLinks){
    navToggle.addEventListener('click', () => navLinks.classList.toggle('open'));
    navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => navLinks.classList.remove('open')));
  }
});
